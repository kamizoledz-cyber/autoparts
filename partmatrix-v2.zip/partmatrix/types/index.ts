export type Manufacturer = {
  id: string;
  name: string;
  country: string;
  founded_year?: number;
  logo?: string;
  status: string;
};

export type Model = {
  id: string;
  manufacturer_id: string;
  name: string;
  segment?: string;
  production_start?: number;
  production_end?: number;
  status: string;
  manufacturer?: Manufacturer;
};

export type Generation = {
  id: string;
  model_id: string;
  code?: string;
  name: string;
  production_start?: number;
  production_end?: number;
  status: string;
  model?: Model;
};

export type Engine = {
  id: string;
  code: string;
  manufacturer_id: string;
  displacement?: number;
  fuel_type?: string;
  cylinders?: number;
  horsepower?: number;
  torque_nm?: number;
};

export type Transmission = {
  id: string;
  name: string;
  type?: string;
  gears?: number;
  manufacturer?: string;
};

export type Market = {
  id: string;
  name: string;
  code?: string;
};

export type VehicleVersion = {
  id: string;
  generation_id: string;
  engine_id?: string;
  transmission_id?: string;
  market_id?: string;
  production_year?: number;
  trim?: string;
  drive_type?: string;
  doors?: number;
  body_type?: string;
  status: string;
  generation?: Generation;
  engine?: Engine;
  transmission?: Transmission;
  market?: Market;
};

export type Category = {
  id: string;
  name: string;
  description?: string;
  icon?: string;
};

export type Part = {
  id: string;
  category_id: string;
  manufacturer_id: string;
  name: string;
  description?: string;
  oem_number?: string;
  difficulty?: string;
  installation_time?: number;
  status: string;
  category?: Category;
  manufacturer?: Manufacturer;
};

export type CompatibilityRow = {
  id: number;
  vehicle_version_id: string;
  part_id: string;
  quantity?: number;
  note?: string;
  part?: Part;
};

export type SearchResult = {
  vehicle: VehicleVersion;
  generation: Generation;
  model: Model;
  manufacturer: Manufacturer;
  engine?: Engine;
  transmission?: Transmission;
  market?: Market;
  parts: CompatibilityRow[];
};
