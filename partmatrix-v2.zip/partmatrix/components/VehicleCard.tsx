"use client";
import { useState, useEffect } from "react";
import { getCompatibleParts } from "@/lib/supabase";

export default function VehicleCard({ vehicle }: { vehicle: any }) {
  const [parts, setParts]       = useState<any[]>([]);
  const [loading, setLoading]   = useState(true);
  const [expanded, setExpanded] = useState(false);

  const gen = vehicle.generation;
  const model = gen?.model;
  const mfr = model?.manufacturer;

  useEffect(() => {
    getCompatibleParts(vehicle.id).then((data) => {
      setParts(data);
      setLoading(false);
    });
  }, [vehicle.id]);

  return (
    <div className="pm-card-hover">
      {/* ── Header ── */}
      <div className="border-b border-pm-border pb-4 mb-5">
        <h2 className="text-2xl font-bold mb-1">
          🚗 {mfr?.name} {model?.name}
        </h2>
        <p className="text-pm-muted text-sm">
          {gen?.name} · {vehicle.production_year} · {vehicle.trim}
        </p>
      </div>

      {/* ── Info grid ── */}
      <div className="pm-info-grid mb-5">
        {vehicle.engine && (
          <>
            <InfoCell label="Engine"       value={vehicle.engine.code} />
            <InfoCell label="Displacement" value={`${vehicle.engine.displacement}L`} />
            <InfoCell label="Fuel"         value={vehicle.engine.fuel_type} />
            <InfoCell label="Power"        value={`${vehicle.engine.horsepower} HP`} />
          </>
        )}
        {vehicle.transmission && (
          <InfoCell label="Transmission" value={vehicle.transmission.name} />
        )}
        {vehicle.market && (
          <InfoCell label="Market" value={vehicle.market.name} />
        )}
        <InfoCell label="Body"  value={vehicle.body_type ?? "-"} />
        <InfoCell label="Drive" value={vehicle.drive_type ?? "-"} />
      </div>

      {/* ── Compatible parts ── */}
      <button
        onClick={() => setExpanded(!expanded)}
        className="text-pm-sky text-sm font-medium hover:underline mb-3 block"
      >
        {loading
          ? "Loading parts..."
          : `🔗 Compatible Parts (${parts.length}) ${expanded ? "▲" : "▼"}`}
      </button>

      {expanded && (
        <div className="flex flex-col gap-3">
          {parts.length === 0 ? (
            <p className="text-pm-muted text-sm">No compatible parts found</p>
          ) : (
            parts.map((row: any) => (
              <div key={row.id}
                className="bg-pm-card border border-pm-border2 rounded-xl px-4 py-3
                           transition-all duration-200 hover:border-blue-500 hover:translate-x-1">
                <p className="text-pm-sky font-semibold">{row.part?.name}</p>
                <p className="text-pm-muted text-xs mt-1">{row.part?.description}</p>
                <div className="flex gap-2 mt-2 flex-wrap">
                  {row.part?.category && (
                    <span className="pm-badge text-xs">📂 {row.part.category.name}</span>
                  )}
                  {row.note && (
                    <span className="pm-badge text-xs">📝 {row.note}</span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <p className="pm-info-cell">
      <span className="text-pm-muted mr-1">{label}:</span>
      {value}
    </p>
  );
}
