"use client";
import Link from "next/link";

const LANGS = ["EN", "AR", "FR", "ES"];

export default function Header() {
  return (
    <header className="sticky top-0 z-50 flex justify-between items-center
                       px-[8%] py-[22px] bg-pm-surface border-b border-pm-border
                       backdrop-blur-md">
      <Link href="/" className="flex flex-col no-underline">
        <span className="text-3xl font-bold text-white">🚗 PartMatrix</span>
        <span className="text-[13px] text-pm-muted mt-1">
          Global Auto Parts &amp; Compatibility Platform
        </span>
      </Link>

      <div className="flex gap-3">
        {LANGS.map((l) => (
          <button key={l}
            className="bg-pm-card text-white border-none px-3.5 py-2.5
                       rounded-xl cursor-pointer transition-all duration-200
                       hover:bg-pm-blue text-sm font-medium">
            {l}
          </button>
        ))}
      </div>
    </header>
  );
}
