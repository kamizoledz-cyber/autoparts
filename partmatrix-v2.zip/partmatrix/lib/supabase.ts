import { createClient } from "@supabase/supabase-js";

export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// ─── Search across the full hierarchy ─────────────────────
export async function searchPartMatrix(query: string) {
  const q = query.trim();
  if (!q) return { vehicles: [], parts: [], manufacturers: [] };

  const [vehiclesRes, partsRes, mfrRes] = await Promise.all([
    // Search vehicles via generation → model → manufacturer
    supabase
      .from("vehicle_versions")
      .select(`
        *,
        generation:generations(
          *,
          model:models(
            *,
            manufacturer:manufacturers(*)
          )
        ),
        engine:engines(*),
        transmission:transmissions(*),
        market:markets(*)
      `)
      .eq("status", "Active"),

    // Search parts
    supabase
      .from("parts")
      .select("*, category:categories(*), manufacturer:manufacturers(*)")
      .or(`name.ilike.%${q}%,description.ilike.%${q}%,oem_number.ilike.%${q}%`)
      .eq("status", "Active")
      .limit(20),

    // Search manufacturers
    supabase
      .from("manufacturers")
      .select("*")
      .or(`name.ilike.%${q}%,country.ilike.%${q}%`)
      .eq("status", "Active")
      .limit(10),
  ]);

  // Filter vehicles client-side (full text across hierarchy)
  const ql = q.toLowerCase();
  const filteredVehicles = (vehiclesRes.data ?? []).filter((v: any) => {
    const text = [
      v.generation?.model?.manufacturer?.name,
      v.generation?.model?.name,
      v.generation?.name,
      v.generation?.code,
      v.engine?.code,
      v.trim,
      v.body_type,
      v.production_year,
      v.market?.name,
    ].join(" ").toLowerCase();
    return text.includes(ql);
  });

  return {
    vehicles:      filteredVehicles,
    parts:         partsRes.data ?? [],
    manufacturers: mfrRes.data ?? [],
  };
}

// ─── Get compatible parts for a vehicle ───────────────────
export async function getCompatibleParts(vehicleId: string) {
  const { data } = await supabase
    .from("compatibility")
    .select("*, part:parts(*, category:categories(*), manufacturer:manufacturers(*))")
    .eq("vehicle_version_id", vehicleId);
  return data ?? [];
}

// ─── Get all manufacturers ─────────────────────────────────
export async function getManufacturers() {
  const { data } = await supabase
    .from("manufacturers")
    .select("*")
    .eq("status", "Active")
    .order("name");
  return data ?? [];
}

// ─── Get all categories ────────────────────────────────────
export async function getCategories() {
  const { data } = await supabase
    .from("categories")
    .select("*")
    .eq("status", "Active");
  return data ?? [];
}
