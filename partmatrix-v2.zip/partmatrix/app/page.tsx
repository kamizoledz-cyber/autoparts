"use client";

import { useState } from "react";
import Header from "@/components/Header";
import VehicleCard from "@/components/VehicleCard";
import { searchPartMatrix } from "@/lib/supabase";

const STATS = [
  { value: "10+",  label: "Manufacturers" },
  { value: "500+", label: "Vehicle Models" },
  { value: "50K+", label: "Parts Listed" },
  { value: "9",    label: "Global Markets" },
];

const BRANDS = [
  "Toyota","BMW","Mercedes-Benz","Volkswagen",
  "Ford","Hyundai","Renault","Honda","Geely","Stellantis",
];

type Results = {
  vehicles: any[];
  parts: any[];
  manufacturers: any[];
};

export default function Home() {
  const [query,   setQuery]   = useState("");
  const [results, setResults] = useState<Results | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSearch(q?: string) {
    const val = q ?? query;
    if (!val.trim()) return;
    if (q) setQuery(q);
    setLoading(true);
    setResults(null);
    const data = await searchPartMatrix(val);
    setResults(data);
    setLoading(false);
  }

  const total = results
    ? results.vehicles.length + results.parts.length + results.manufacturers.length
    : 0;

  return (
    <>
      <Header />

      <main className="max-w-[1200px] mx-auto px-5 py-[70px]">

        {/* Hero */}
        <h1 className="text-center font-bold leading-tight mb-4
                       text-[52px] max-sm:text-[34px]">
          Find Any Auto Part Worldwide
        </h1>
        <p className="text-center text-pm-muted text-lg mb-0">
          Search by Manufacturer, Model, Generation, Engine or OEM Number
        </p>

        {/* Search box */}
        <div className="flex max-w-[760px] mx-auto mt-11 mb-0
                        bg-pm-card rounded-2xl overflow-hidden border border-pm-border2
                        max-sm:flex-col">
          <input
            className="flex-1 bg-transparent border-none text-white
                       px-6 py-[18px] text-[17px] outline-none
                       placeholder:text-pm-muted"
            placeholder="Toyota, Corolla, E210, M20A-FKS, Oil Filter..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          />
          <button
            onClick={() => handleSearch()}
            disabled={loading}
            className="pm-btn max-sm:w-full"
          >
            {loading ? "⏳ Searching..." : "🔍 Search"}
          </button>
        </div>

        {/* Results */}
        {results && (
          <section className="mt-10 space-y-6">
            <p className="text-pm-muted text-sm">
              {total === 0
                ? `No results for "${query}"`
                : `${total} result${total !== 1 ? "s" : ""} for "${query}"`}
            </p>

            {/* Manufacturers */}
            {results.manufacturers.map((m: any) => (
              <div key={m.id} className="pm-card-hover">
                <h3 className="text-2xl font-bold mb-3">🏭 {m.name}</h3>
                <div className="flex gap-2 flex-wrap">
                  <span className="pm-badge">🌍 {m.country}</span>
                  {m.founded_year && (
                    <span className="pm-badge">📅 Est. {m.founded_year}</span>
                  )}
                </div>
              </div>
            ))}

            {/* Vehicles */}
            {results.vehicles.map((v: any) => (
              <VehicleCard key={v.id} vehicle={v} />
            ))}

            {/* Parts */}
            {results.parts.map((p: any) => (
              <div key={p.id} className="pm-card-hover">
                <h3 className="text-pm-sky text-2xl font-bold mb-2">
                  🔧 {p.name}
                </h3>
                <p className="text-pm-text mb-3">{p.description}</p>
                <div className="flex gap-2 flex-wrap">
                  {p.category && (
                    <span className="pm-badge">📂 {p.category.name}</span>
                  )}
                  {p.manufacturer && (
                    <span className="pm-badge">🏭 {p.manufacturer.name}</span>
                  )}
                  {p.oem_number && (
                    <span className="pm-badge">OEM: {p.oem_number}</span>
                  )}
                  {p.difficulty && (
                    <span className="pm-badge">🔧 {p.difficulty}</span>
                  )}
                </div>
              </div>
            ))}

            {total === 0 && (
              <div className="text-center py-16">
                <h2 className="text-pm-sky text-2xl mb-2">🔍 No Results Found</h2>
                <p className="text-pm-muted">
                  Try another keyword — brand, model, engine code, or OEM number
                </p>
              </div>
            )}
          </section>
        )}

        {/* Stats + Brands (shown when no search) */}
        {!results && (
          <>
            <div className="grid grid-cols-[repeat(auto-fit,minmax(220px,1fr))]
                            gap-5 mt-16 max-sm:grid-cols-1">
              {STATS.map((s) => (
                <div key={s.label} className="pm-card text-center">
                  <h2 className="text-pm-sky text-4xl font-bold mb-2">{s.value}</h2>
                  <p className="text-pm-muted">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="mt-[70px]">
              <h2 className="text-center text-2xl font-bold mb-8">Supported Brands</h2>
              <div className="grid grid-cols-[repeat(auto-fit,minmax(160px,1fr))]
                              gap-5 max-sm:grid-cols-2">
                {BRANDS.map((b) => (
                  <button
                    key={b}
                    onClick={() => handleSearch(b)}
                    className="bg-pm-surface border border-pm-border rounded-2xl
                               p-6 text-center cursor-pointer font-medium text-sm
                               transition-all duration-200
                               hover:-translate-y-1 hover:border-blue-500 hover:bg-[#16213b]">
                    {b}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </main>

      <footer className="mt-20 text-center py-8 text-pm-muted
                         border-t border-pm-border text-sm">
        © {new Date().getFullYear()} PartMatrix — Global Auto Parts &amp; Compatibility Platform
      </footer>
    </>
  );
}
