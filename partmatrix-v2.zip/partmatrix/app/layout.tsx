import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PartMatrix — Global Auto Parts & Compatibility Platform",
  description:
    "Find compatible auto parts for any vehicle worldwide. OEM references, cross-reference database, tire tools, and compatibility finder.",
  keywords: "auto parts, car parts, OEM, compatibility, Toyota, BMW, Mercedes",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-pm-bg text-white min-h-screen antialiased">
        {children}
      </body>
    </html>
  );
}
