import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        pm: {
          bg:      "#0f172a",
          surface: "#111827",
          card:    "#1e293b",
          border:  "#263247",
          border2: "#334155",
          blue:    "#2563eb",
          blueh:   "#1d4ed8",
          sky:     "#38bdf8",
          muted:   "#94a3b8",
          text:    "#e2e8f0",
        },
      },
      fontFamily: {
        sans: ["Arial", "Helvetica", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
